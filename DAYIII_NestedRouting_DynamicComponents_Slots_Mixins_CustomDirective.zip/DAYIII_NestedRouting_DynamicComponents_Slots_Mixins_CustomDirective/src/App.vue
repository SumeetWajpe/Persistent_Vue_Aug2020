<template>
<v-app>
    <v-app-bar app color="primary" dark>
        <div class="d-flex align-center">
            <v-img alt="Vuetify Logo" class="shrink mr-2" contain src="https://cdn.vuetifyjs.com/images/logos/vuetify-logo-dark.png" transition="scale-transition" width="40" />

                <h1 class="display-2 d-flex text-uppercase"><span class="font-weight-light">Online </span> Shopping</h1>
 </div>
        <v-spacer></v-spacer>

        <v-btn class="mx-3 white--text">
            <router-link to="/dashboard/cart">Home</router-link>
        </v-btn>

        <v-btn class="mx-3 white--text">
            <router-link to="/dashboard/posts">Posts</router-link>

        </v-btn>
        <v-btn class="mx-3 white--text">
            <router-link to="/login">Log In</router-link>
        </v-btn>
          <v-btn class="mx-3 white--text">
            <router-link to="/courses">Courses</router-link>
        </v-btn>

        <v-spacer></v-spacer>

        <v-btn href="https://github.com/vuetifyjs/vuetify/releases/latest" target="_blank" text>

        </v-btn>
    </v-app-bar>

    <v-main>
        <v-container>
            <!-- <ShoppingCart/> -->
            <!-- <Posts/> -->
            <router-view></router-view>
        </v-container>
    </v-main>
</v-app>
</template>

<script>
export default {
    name: 'App',

    components: {

    },

    data: () => ({
        //
    }),
};
</script>
