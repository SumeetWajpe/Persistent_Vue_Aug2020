export const courseMixin ={
    data(){
        return {
            courses:['Angular','React','Vue'],
            filterText:''
        }
    },
    computed:{
        filterCourses(){
            return this.courses.filter(c=>c.match(this.filterText))
        }
    }
}