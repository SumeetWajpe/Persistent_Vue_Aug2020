<template>
    <div>
        <Coursera></Coursera>
        <Udemy></Udemy>
    </div>
</template>

<script>

    import Coursera from "./coursera";
    import Udemy from "./udemy";


    export default {
        name:'Courses',
        components:{Coursera,Udemy}
       
    }
</script>

<style scoped>

</style>