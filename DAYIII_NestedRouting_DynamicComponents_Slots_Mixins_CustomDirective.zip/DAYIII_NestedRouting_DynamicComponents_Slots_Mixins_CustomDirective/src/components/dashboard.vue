<template>
    <div>
        <h1>Dashboard</h1>
        <!-- <Blog :headline="heading">     
            <template v-slot:default="myheading">
                <h3>{{myheading.h}}</h3>
            </template>
            <template v-slot:content>
                    <i> This is the content for the Blog !</i>
            </template>
             <template v-slot:footer>
                    <p> @ Copyright 2020</p>
            </template>
        </Blog> -->

         <router-view></router-view>
      <!--  <router-view name="postsview"></router-view>
        -->
    </div>
</template>

<script>
// import Blog from './blog';
    export default {
        name:'Dashboard',
        components:{},
        data(){
            return {
                heading:'Blog Heading From Dashboard'
            }
        }
    }
</script>

<style scoped>

</style>