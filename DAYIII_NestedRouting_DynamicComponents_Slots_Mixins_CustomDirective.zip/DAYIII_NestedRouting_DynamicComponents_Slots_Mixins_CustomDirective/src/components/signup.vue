<template>
     <v-card class="px-10 my-10 py-10" elevation="6">
        <h1>Sign Up</h1>
        Username : <input type="text"> <br/>
        Password : <input type="password"> <br/>
        Confirm Password : <input type="password"> <br/>
        Email : <input type="email" /> <br/>
        <v-btn color="success"> Sign Up</v-btn>
    </v-card>  
</template>

<script>
    export default {
        name:'SignUp'
    }
</script>

<style scoped>

</style>