<template>
<div>
     <v-card class="px-10 my-10 py-10" elevation="6">
    <h1>Coursera has {{noOfCourses}} courses </h1>
    Search your course : <input type="text" v-model="filterText" />
    <ul>
        <li v-for="c in filterCourses" :key="c">{{c}}</li>
    </ul>
     </v-card>
</div>
</template>

<script>
import {
    courseMixin
} from '../mixins/courseMixin';
export default {
    name: 'Coursera',
    data(){
        return {
            noOfCourses:1000,
             courses:['HTML','C#']
        }
    },
    mixins: [courseMixin]
}
</script>

<style scoped>

</style>
