<template>
      <v-card class="px-10 my-10 py-10" elevation="6">
        <h1>Sign In</h1>
        Username : <input type="text"> <br/>
        Password : <input type="password"> <br/>
        <v-btn color="success"> Sign In</v-btn>
    </v-card>   
</template>

<script>
    export default {
        name:'SignIn'
    }
</script>

<style scoped>

</style>