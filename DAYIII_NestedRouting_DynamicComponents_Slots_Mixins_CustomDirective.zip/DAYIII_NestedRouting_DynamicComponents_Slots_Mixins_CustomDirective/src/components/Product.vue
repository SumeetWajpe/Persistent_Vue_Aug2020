<template>
<v-card :class="isSelected ? 'success lighten-5':''">
    <slot name="header"></slot>
     <v-divider></v-divider>
     <slot name="maincontent"></slot> 
    <v-divider></v-divider>

    <v-card-actions>
        <v-btn color="indigo" dark fab @click="productdetails.likes++">
            <v-icon>mdi-thumb-up</v-icon>
        </v-btn>
        <v-btn color="red" dark fab outlined
        @click="DeleteProduct(productdetails.id)">
            <v-icon>mdi-delete</v-icon>
        </v-btn>
        <v-switch class="mx-4"
         label="Add to cart"
         :disabled="!productdetails.quantity"
         v-model="isSelected"
         ></v-switch>
    </v-card-actions>
</v-card>

</template>

<script>
export default {
    name: 'Product',
    data(){
        return {
            isSelected:false
        }
    },
    props: {
        productdetails: Object
    },
    filters:{
        currency(val,args){
            return `${args}${val}`
        }
    },methods:{
        DeleteProduct(theId){
            this.$emit('delete-a-product',theId);
        }
    }
}
</script>

<style scoped>

</style>
