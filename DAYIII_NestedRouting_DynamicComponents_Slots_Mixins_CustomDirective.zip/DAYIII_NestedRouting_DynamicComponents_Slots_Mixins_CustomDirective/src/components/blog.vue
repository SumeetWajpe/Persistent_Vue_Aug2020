<template>
    <div>        
        <slot :h="headline"></slot>
        <slot name="content"></slot>
        <slot name="footer"></slot>      
    </div>
</template>

<script>
    export default {
        name:'Blog',
        props:['headline']          
        
        // data(){
        //     return {
        //         heading:'Blog Heading'
        //     }
        // }
    }
</script>

<style scoped>

</style>