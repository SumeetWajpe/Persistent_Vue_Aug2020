<template>
<div>
     <v-card class="px-10 my-10 py-10" elevation="6">
    <h1>Udemy</h1>

<v-btn color="red" dark  type="button" @click="courses.push('Typescript')">Add New Course</v-btn>
    <ul>
        <li v-for="c in courses" :key="c">{{c}}</li>
    </ul>
     </v-card>
</div>
</template>

<script>
import {
    courseMixin
} from '../mixins/courseMixin';
export default {
    name: 'Udemy',
    mixins: [courseMixin]

}
</script>

<style scoped>

</style>
