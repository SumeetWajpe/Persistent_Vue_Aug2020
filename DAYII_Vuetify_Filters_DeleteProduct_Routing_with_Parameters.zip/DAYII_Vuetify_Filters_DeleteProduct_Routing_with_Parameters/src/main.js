import Vue from 'vue'
import App from './App.vue'
import vuetify from './plugins/vuetify';
import VueRouter from 'vue-router';
import ShoppingCart from './components/ShoppingCart';
import Posts from './components/posts';
import PostDetails from './components/postdetails';

Vue.config.productionTip = false

Vue.use(VueRouter); 
// routes 

const routes = [
  {path:'/',component:ShoppingCart},
  {path:'/posts',component:Posts},
  {path:'/postdetails/:id',component:PostDetails,name:'postdetails'}
];

var router = new VueRouter({
  routes,
  mode:'history'
});

Vue.filter('outofstock',function(val,args){
  switch(val){
    case 0:
      return 'OUT OF STOCK';
    case 1:
      return val + args.substring(0,args.length-1);
      default:
        return val + " " + args;
  }
});

new Vue({
  vuetify,
  router,
  render: h => h(App)
}).$mount('#app');


