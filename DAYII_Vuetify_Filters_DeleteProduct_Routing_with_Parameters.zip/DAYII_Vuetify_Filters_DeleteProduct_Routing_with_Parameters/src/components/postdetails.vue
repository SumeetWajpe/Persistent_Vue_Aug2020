<template>
    <div>
        <h1>Post Details for {{postId}}</h1>
    </div>
</template>

<script>
    export default {
        name:'PostDetails',
        data(){
            return{
                postId : this.$route.params.id
            }
        }
    }
</script>

<style scoped>

</style>