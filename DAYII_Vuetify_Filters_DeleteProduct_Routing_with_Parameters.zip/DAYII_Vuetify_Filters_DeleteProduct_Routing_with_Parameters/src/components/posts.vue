<template>
    <div>
        <h1> All Posts </h1>
        <ul>
            <li v-for="post in allPosts" :key="post.id" >
               <!-- <router-link to="`/postdetails/${post.id}`"> {{post.title}} </router-link> -->
               <router-link :to="{name:'postdetails',params:{id:post.id} }"> {{post.title}} </router-link>

            </li>
        </ul>
    </div>
</template>



<script>
import axios from 'axios';
    export default {
        name:'Posts',
        data(){
            return {
                allPosts:[]
            }
        },
        mounted(){
            axios.get('https://jsonplaceholder.typicode.com/posts')
            .then(response => this.allPosts = response.data )
        }
    }
</script>

<style scoped>

</style>