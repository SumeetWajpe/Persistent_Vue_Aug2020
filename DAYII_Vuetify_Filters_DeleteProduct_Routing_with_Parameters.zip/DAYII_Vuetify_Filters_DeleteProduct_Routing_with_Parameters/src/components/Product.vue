<template>
<v-card :class="isSelected ? 'success lighten-5':''">
     <v-card-title class="display-1">{{productdetails.title }}</v-card-title>
     <v-divider></v-divider>
    <v-img class="white--text align-end" height="250px" 
    width="350px" :src="productdetails.ImageUrl"
    :style="productdetails.quantity ? '':{opacity:0.4}" 
    >
                    </v-img>
                   
                   <span v-if="productdetails.quantity">
                       Available
                   </span>                   
                   <span v-else>
                       Unavailable
                   </span>                    
                    <v-card-text class="text--primary subtitle-1">
                        <div><b>Price : </b>{{productdetails.price | currency('₹') }} </div>
                        <div><b>Rating : </b>{{productdetails.rating }} </div>
                        <div><b>Quantity : </b>{{productdetails.quantity | outofstock('nos') }} </div>
                        <div><b>Likes : </b>{{productdetails.likes }} </div>
                    </v-card-text>
    <v-divider></v-divider>

    <v-card-actions>
        <v-btn color="indigo" dark fab @click="productdetails.likes++">
            <v-icon>mdi-thumb-up</v-icon>
        </v-btn>
        <v-btn color="red" dark fab outlined
        @click="DeleteProduct(productdetails.id)">
            <v-icon>mdi-delete</v-icon>
        </v-btn>
        <v-switch class="mx-4"
         label="Add to cart"
         :disabled="!productdetails.quantity"
         v-model="isSelected"
         ></v-switch>
    </v-card-actions>
</v-card>

</template>

<script>
export default {
    name: 'Product',
    data(){
        return {
            isSelected:false
        }
    },
    props: {
        productdetails: Object
    },
    filters:{
        currency(val,args){
            return `${args}${val}`
        }
    },methods:{
        DeleteProduct(theId){
            this.$emit('delete-a-product',theId);
        }
    }
}
</script>

<style scoped>

</style>
