<template>
  <div id="app">
      <course v-for="(c) in courses"
        v-bind:key="c.name" 
        :course-details="c">
        </course> 
  </div>
</template>

<script>
// import HelloWorld from './components/HelloWorld.vue';
import Course from './components/course';

export default {
  name: 'App',
  components: {
    Course
  },
  data(){
    return {
      courses:[
                    {name:'Vue',price:5000},
                    {name:'Stencil',price:6000},
                    {name:'Lerna',price:3000}
                ]
    }
  }
}
</script>

<style>
#app {
  
}
</style>
