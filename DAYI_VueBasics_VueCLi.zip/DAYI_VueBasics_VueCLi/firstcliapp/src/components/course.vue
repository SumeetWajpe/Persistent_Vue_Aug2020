<template>
     <div class="courseStyle">
                <h1>{{courseDetails.name}}</h1>                
                <h5>{{courseDetails.price}}</h5>
            </div>
</template>

<script>
    export default {
        name:'Course',
        props:{
            courseDetails:{
                type:Object,
                required:true
            }
        }
    }
</script>

<style>
    .courseStyle{
        border:1px solid red;
        border-radius: 10px;
        margin: 10px;
        padding: 10px;
        height: 300px;
        width:300px;
    }
</style>