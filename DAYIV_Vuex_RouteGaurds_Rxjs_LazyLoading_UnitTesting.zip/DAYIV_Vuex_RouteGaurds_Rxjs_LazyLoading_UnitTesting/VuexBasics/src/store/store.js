import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex);

export const store = new Vuex.Store({
    state:{
        counter:0,// global data,        
        products:[]
    },
    getters:{
        getCurrentCount:state=>{
            return state.counter;
        }
    }
    ,
    mutations:{ // change logic
        incrementcount:(state,payload)=>{
            if(payload >= 50){
                state.counter+=payload;
            }
            else{
                state.counter++; // counter++
            }
        }
    },
    actions:{ // pass the payload to mutations, can have async ops
        // increment:(args)=>{
        //     console.log(args);
        //     args.commit('incrementcount')            
        // }
        increment:({commit},payload)=>{            
            commit('incrementcount',payload)            
        },
        incrementAsync:({commit},payload)=>{   
            setTimeout(()=>{
                commit('incrementcount',payload); 
            },3000)         
        }
    }
});

// Destructuring in ES 6
// let name;
// var person = {name:'Virat'};
// ({name} = person);