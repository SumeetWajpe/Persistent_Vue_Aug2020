<template>
    <div>
        <h1>Current Count (Result Component) : {{getCurrentCount}} </h1>
          </div>
</template>

<script>
import {mapGetters} from 'vuex';

    export default {
        name:'Result',
        computed:{
           ...mapGetters(['getCurrentCount'])
        }
        
    }
</script>

<style scoped>

</style>