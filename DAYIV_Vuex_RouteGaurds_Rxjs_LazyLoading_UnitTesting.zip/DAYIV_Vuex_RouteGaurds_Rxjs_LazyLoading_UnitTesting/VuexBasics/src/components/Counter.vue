<template>
    <div>
        <p>Count : {{getCurrentCount}} </p>
        <input type="button" value="++" @click="increment(50)" /> 
        <input type="button" value="++Async" @click="incrementAsync(100)" /> 

    </div>
</template>

<script>
import {mapGetters, mapActions} from 'vuex';

    export default {
        name:'Counter',
        computed:{
           ...mapGetters(['getCurrentCount'])
        },
        methods:{
            // incrementValue(incrementBy){
            //     // dispatching an action here
            //     this.$store.dispatch('increment',incrementBy);
            // }
            ...mapActions(['increment','incrementAsync'])
        }
    }
</script>

<style scoped>

</style>