import Vue from "vue";
import Vuex from "vuex";
import Axios from "axios";

Vue.use(Vuex);

export const store = new Vuex.Store({
  state: {
    products: [],
    isAuthenticated : false
  },
  getters: {
    getAllProducts: (state) => {
      return state.products;
    },
  },
  mutations: {
    // change logic
    incrementlikes: (state, payload) => {
      /// logic to increment the likes of the product !
      let index = state.products.findIndex((p) => p.id === payload);
      state.products[index].likes++;
    },
    deleteproduct: (state, payload) => {
      /// logic to delete the product !
      let index = state.products.findIndex((p) => p.id === payload);
      state.products.splice(index, 1);
    },
    fetchproducts: (state, payload) => {
      /// logic to delete the product !
      state.products = payload; // response
    },
    setauthentication:(state, payload) => {
        /// logic to set authentication
        state.isAuthenticated = payload; 
      },
  },
  actions: {
    // pass the payload to mutations, can have async ops
    incrementLikes: ({ commit }, payload) => {
      commit("incrementlikes", payload);
    },
    deleteProduct: ({ commit }, payload) => {
      commit("deleteproduct", payload);
    },
    fetchProducts: ({ commit }) => {
      Axios.get("../products.json").then(response =>
        commit("fetchproducts", response.data),
        err=>console.log(err)
      );
    },
    setAuthentication: ({ commit }, payload) => {
        commit("setauthentication", payload);
      },
  },
});
