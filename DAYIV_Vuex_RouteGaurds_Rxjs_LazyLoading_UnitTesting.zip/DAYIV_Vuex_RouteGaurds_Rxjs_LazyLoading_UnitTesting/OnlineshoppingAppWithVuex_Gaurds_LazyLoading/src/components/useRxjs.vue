<template>
    <div>
        <p>Count : {{count}} </p>
    </div>
</template>

<script>
import {interval} from 'rxjs';


    export default {
        name:'RxJSCounter',
        data(){
            return {
                count:0
            }
        },
        created(){
            const obsv = interval(1000);
            obsv.subscribe(value => this.count = value)
        }
    }
</script>

<style scoped>

</style>