<template>
<div>
    <v-btn color="indigo" dark @click="componentToBeCreated='sign-in'">
        Sign In
    </v-btn>
    <v-btn color="indigo" dark @click="componentToBeCreated='sign-up'">
        Sign Up
    </v-btn>
    <!-- location where the component is to instantiated dynamically -->
    <keep-alive>
        <transition name="fade">
            <component :is="componentToBeCreated">
            </component>
        </transition>
    </keep-alive>

</div>
</template>

<script>
import SignUp from './signup';
import SignIn from './signin';

export default {
    name: 'DynamicComponent',
    components: {
        'sign-up': SignUp,
        'sign-in': SignIn
    },
    data() {
        return {
            componentToBeCreated: 'sign-in'
        }
    }
}
</script>

<style scoped>
.fade-enter-active, .fade-leave-active {
  transition: opacity 1s;
}
.fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  opacity: 0;
}
</style>
