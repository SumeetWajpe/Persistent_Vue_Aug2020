<template>
      <v-card class="px-10 my-10 py-10" elevation="6">
        <h1>Sign In</h1>
        Username : <input type="text" v-model="user.username"> <br/>
        Password : <input type="password" v-model="user.password"> <br/>
        <v-btn color="success" @click="login"> Sign In</v-btn>
    </v-card>   
</template>

<script>
    export default {
        name:'SignIn',
        data(){
            return {
                user:{
                    username:'',
                    password:''
                }
            }
        },methods:{
            login(){
                if(this.user.username == "admin" && this.user.password == "admin"){
                    this.$store.dispatch('setAuthentication',true);
                    this.$router.replace({name:'dashboard'});
                }
                else{
                    console.log('Username and/or password incorrect !');
                }
            }
        }
    }
</script>

<style scoped>

</style>