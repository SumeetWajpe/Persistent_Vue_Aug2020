<template>
<div>

    <v-row>
        <v-col cols="12" sm="4" v-for="product in getAllProducts" :key="product.id">
            <Product :productdetails="product">
                <template v-slot:header>
                    <v-card-title class="display-1">{{product.title }}</v-card-title>
                </template>
                <template v-slot:maincontent>
                    <v-img class="white--text align-end" height="250px" width="350px" :src="product.ImageUrl" :style="product.quantity ? '':{opacity:0.4}">
                    </v-img>

                    <span v-if="product.quantity">
                        Available
                    </span>
                    <span v-else>
                        Unavailable
                    </span>
                    <v-card-text class="text--primary subtitle-1">
                        <div><b>Price : </b>{{product.price | currency('₹') }} </div>
                        <div><b>Rating : </b>{{product.rating }} </div>
                        <div><b>Quantity : </b>{{product.quantity | outofstock('nos') }} </div>
                        <div><b>Likes : </b>{{product.likes }} </div>
                    </v-card-text>
                </template>
            </Product>
            <!-- slot name -> header , maincontent , footer -->
        </v-col>
    </v-row>

</div>
</template>

<script>
import Product from './Product';
import {mapGetters} from 'vuex';

export default {
    name: 'ShoppingCart',
    components: {
        Product
    },    
    computed:{
        ...mapGetters(['getAllProducts'])
    },
    mounted(){
        this.$store.dispatch('fetchProducts');
    },
    methods: {

    }
}
</script>

<style>

</style>
