import Vue from 'vue'
import App from './App.vue'
import vuetify from './plugins/vuetify';
import VueRouter from 'vue-router';
import ShoppingCart from './components/ShoppingCart';
// import Posts from './components/posts';
import PostDetails from './components/postdetails';
import Dashboard from './components/dashboard';
import DynamicComponent from './components/dynamiccomponent';
// import Blog from './components/blog';
 import Courses from './components/courses';
import {store} from './store/store';
import RxJSCounter from "./components/useRxjs";
// Lazy Loading
const Posts = () => import("./components/posts");

Vue.config.productionTip = false

Vue.use(VueRouter); 


// routes 

// const routes = [
//   {path:'/',component:ShoppingCart},
//   {path:'/posts',component:Posts},
//   {path:'/postdetails/:id',component:PostDetails,name:'postdetails'}
// ];


// Global Mixin
// Vue.mixin({
// })

const routes=[
  {path:'/dashboard',  
  component:Dashboard,
  children:[
    {path:'',component:ShoppingCart,name:'dashboard'},
    {path:'posts',component:Posts},
    {path:'postdetails/:id',component:PostDetails,name:'pd'},
    {path:'/courses',component:Courses}
   

  ],
  beforeEnter:(to,from,next)=>{
    if(store.state.isAuthenticated == false){
      next('/');
    }else{
      next();// as planned
    }
  }

},
  {path:'/',component:DynamicComponent}, 
  {path:'/rxjs',component:RxJSCounter}
]


// const routes=[
//   {path:'/dashboard',
//   component:Dashboard,
//   children:[
//     {path:'',components:{default:ShoppingCart,postsview:Posts}}
//   ]}
// ]
var router = new VueRouter({
  routes,
  mode:'history'
});


Vue.directive('highlight',{
  bind(el,binding){ // bind gets called when directive get attached to the Element
    if(binding.modifiers['delayed']){
      setTimeout(()=>{
        if(binding.arg == 'background'){
          el.style.backgroundColor = binding.value.bcolor;// 'green';
        }else{
          el.style.border = '2px solid red';
          el.style.borderRadius = '5px';
          el.style.padding = '5px';
          el.style.margin = '5px'; 
        }
      },binding.value.delayBy)
    }    
  }
});


Vue.filter('outofstock',function(val,args){
  switch(val){
    case 0:
      return 'OUT OF STOCK';
    case 1:
      return val + args.substring(0,args.length-1);
      default:
        return val + " " + args;
  }
});

Vue.filter('currency',function(val,args){  
    return `${args}${val}`
})

new Vue({
  store,
  vuetify,
  router,
  render: h => h(App)
}).$mount('#app');


